import pandas as pd
import json
import mysql.connector
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

def embed_and_store():
    df = pd.read_csv("products.csv")

    db = mysql.connector.connect(
        host="your-rds-endpoint",
        user="admin",
        password="password",
        database="shop_db"
    )

    cursor = db.cursor()

    for _, row in df.iterrows():
        embedding = model.encode(row["product_name"]).tolist()
        cursor.execute(
            "INSERT INTO products_vectors VALUES (%s, %s, %s)",
            (row["product_id"], row["product_name"], json.dumps(embedding))
        )
        db.commit()

    cursor.close()
    db.close()

if __name__ == "__main__":
    embed_and_store()
