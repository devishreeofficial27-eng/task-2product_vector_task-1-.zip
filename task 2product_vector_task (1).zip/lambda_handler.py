import json
import numpy as np
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

def lambda_handler(event, context):
    query = event.get("query")
    query_vector = model.encode(query)

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Top 5 similar products returned"})
    }
