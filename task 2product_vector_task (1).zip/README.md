# Product Vector Similarity Search

This project implements a semantic product search system using vector embeddings.

## Components
- Data generation using Python
- Vector embeddings using HuggingFace
- MySQL database for storage
- AWS Lambda for search
- Terraform for infrastructure

## Similarity Logic
Cosine similarity is used to compare vectors.

## Edge Cases
- Typo handling (Samzung vs Samsung)
- Similar product names (iPhone 14 vs 14 Pro)
