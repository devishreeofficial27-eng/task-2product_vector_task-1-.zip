import csv
import random

def generate_products():
    categories = {
        "Electronics": ["Smartphone", "Laptop", "Headphones", "Smartwatch"],
        "Fashion": ["Running Shoes", "Denim Jacket", "Cotton T-shirt"],
        "Groceries": ["Organic Milk", "Greek Yogurt", "Coffee Beans"]
    }

    products = []
    products.append((1, "Apple iPhone 14 Pro"))
    products.append((2, "Apple iPhone 14"))
    products.append((3, "Samzung Galaxy S21"))

    brands = ["TechCorp", "StyleCo", "PureFoods", "Giga", "Trend"]

    for i in range(4, 501):
        cat = random.choice(list(categories.keys()))
        item = random.choice(categories[cat])
        brand = random.choice(brands)
        products.append((i, f"{brand} {item} {random.randint(100, 999)}"))

    with open("products.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["product_id", "product_name"])
        writer.writerows(products)

if __name__ == "__main__":
    generate_products()
